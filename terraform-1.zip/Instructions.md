### Instructions 

Suivez ces étapes pour cloner le projet, remplacer les variables nécessaires, et déployer l'infrastructure sur AWS à l'aide de Terraform.

#### Étape 1 : Cloner le Dépôt Git
Commencez par cloner le dépôt Git contenant le projet Terraform. Ouvrez votre terminal et exécutez la commande suivante :

```sh
git clone https://github.com/hrhouma/terraform-1.git
```

#### Étape 2 : Naviguer dans le Répertoire du Projet
Après avoir cloné le dépôt, accédez au répertoire du projet :

```sh
cd terraform-1
```

#### Étape 3 : Ouvrir le Projet dans Votre Editeur de Code
Ensuite, ouvrez le projet dans votre éditeur de code (par exemple, Visual Studio Code) en utilisant la commande suivante :

```sh
code .
```

#### Étape 4 : Remplacer les Variables Nécessaires
Avant de déployer l'infrastructure, vous devez remplacer certaines variables dans les fichiers de configuration Terraform. Voici un rappel des variables à remplacer :

1. **lambda_function.py**
   - **`volume_id`** : Remplacez par l'ID du volume EBS que vous souhaitez utiliser.

2. **log.py**
   - **`source_bucket_name`** : Remplacez par le nom de votre bucket S3 source.
   - **`destination_bucket_name`** : Remplacez par le nom de votre bucket S3 de destination.

3. **webpage.py**
   - **`source_bucket_name`** : Remplacez par le nom de votre bucket S3 source.
   - **`destination_bucket_name`** : Remplacez par le nom de votre bucket S3 de destination.

4. **autoscaling.tf**
   - **`image_id`** : Remplacez par l'ID AMI de votre choix.
   - **`key_name`** : Remplacez par le nom de votre paire de clés EC2.
   - **`vpc_zone_identifier`** : Remplacez par les IDs de vos sous-réseaux.
   - **`subnets`** : Remplacez par les IDs de vos sous-réseaux.
   - **`vpc_id`** : Remplacez par votre ID de VPC.

5. **main.tf**
   - **`region`** : Remplacez par la région AWS de votre choix.
   - **`ami`** : Remplacez par l'ID AMI de votre choix.
   - **`key_name`** : Remplacez par le nom de votre paire de clés EC2.

6. **rds.tf**
   - **`username`** : Remplacez par votre nom d'utilisateur souhaité pour la base de données RDS.
   - **`password`** : Remplacez par votre mot de passe souhaité pour la base de données RDS.
   - **`subnet_ids`** : Remplacez par les IDs de vos sous-réseaux.

7. **s3.tf**
   - **`bucket`** : Remplacez par le nom des buckets S3 pour les logs et les pages web.

8. **snapshot.tf**
   - **`endpoint`** : Remplacez par votre adresse email pour recevoir les notifications.
   - **`subnet_ids`** : Remplacez par les IDs de vos sous-réseaux pour les snapshots.

Utilisez votre éditeur de code pour rechercher et remplacer les valeurs mentionnées ci-dessus.

#### Étape 5 : Initialiser Terraform
Une fois les variables remplacées, initialisez Terraform pour configurer votre environnement :

```sh
terraform init
```

#### Étape 6 : Appliquer les Modifications
Déployez l'infrastructure en appliquant les configurations avec Terraform :

```sh
terraform apply --auto-approve
```

#### Étape 7 (Optionnel) : Détruire l'Infrastructure
Si vous souhaitez détruire l'infrastructure créée après avoir terminé, exécutez la commande suivante :

```sh
terraform destroy --auto-approve
```

----
# Annexe :  Prérequis 
----

Avant de lancer Terraform pour déployer l'infrastructure, certaines ressources et configurations doivent être créées ou préparées au préalable. Voici une liste des éléments qui doivent être prêts :

### 1. **Paire de Clés EC2**
   - **Description** : Une paire de clés EC2 est nécessaire pour accéder aux instances EC2 que vous allez créer. Cette paire de clés est utilisée pour se connecter via SSH à vos instances EC2.
   - **Création** : 
     - Créez une nouvelle paire de clés via la console AWS EC2 sous la section "Network & Security" > "Key Pairs".
     - Téléchargez le fichier `.pem` associé à cette paire de clés et conservez-le en lieu sûr.
   - **Usage** : Le nom de cette paire de clés doit être référencé dans les fichiers Terraform (`main.tf` et `autoscaling.tf`).

### 2. **IDs de Sous-Réseaux**
   - **Description** : Les sous-réseaux sont des segments logiques d'un VPC dans lesquels les ressources AWS sont déployées. Vous devez disposer des IDs de sous-réseaux existants dans lesquels les instances EC2, RDS et autres ressources seront créées.
   - **Création** :
     - Si vous n'avez pas encore de sous-réseaux, créez-les dans votre VPC via la console AWS sous "VPC" > "Subnets".
   - **Usage** : Les IDs de sous-réseaux doivent être spécifiés dans les fichiers Terraform (`autoscaling.tf`, `rds.tf`, `snapshot.tf`).

### 3. **ID du VPC**
   - **Description** : Un VPC (Virtual Private Cloud) est une zone de réseau isolée dans laquelle vous déployez vos ressources AWS. Vous devez connaître l'ID de votre VPC pour l'utiliser dans les configurations Terraform.
   - **Création** :
     - Un VPC par défaut est fourni par AWS, mais vous pouvez également créer votre propre VPC via la console AWS sous "VPC" > "Your VPCs".
   - **Usage** : L'ID du VPC doit être référencé dans les fichiers Terraform (`autoscaling.tf`, `main.tf`, `rds.tf`, etc.).

### 4. **Buckets S3 (optionnel)**
   - **Description** : Si votre projet utilise des buckets S3 spécifiques pour stocker des logs ou des pages web, vous pouvez les créer à l'avance ou laisser Terraform les créer.
   - **Création** :
     - Créez les buckets via la console AWS sous "S3".
   - **Usage** : Les noms des buckets doivent être spécifiés dans `s3.tf`.

### 5. **Permissions IAM**
   - **Description** : L'utilisateur ou le rôle IAM exécutant Terraform doit disposer des permissions nécessaires pour créer et gérer toutes les ressources mentionnées dans vos fichiers Terraform.
   - **Création** :
     - Attachez des politiques comme **AdministratorAccess** ou des politiques spécifiques (AmazonEC2FullAccess, AmazonRDSFullAccess, etc.) à l'utilisateur ou au rôle IAM qui exécutera Terraform.

### 6. **Adresse Email pour SNS (optionnel)**
   - **Description** : Si vous configurez des notifications via SNS (Simple Notification Service), vous devez disposer d'une adresse email valide pour recevoir ces notifications.
   - **Création** :
     - Aucune création préalable n'est nécessaire, mais vous devez disposer d'une adresse email que vous spécifierez dans `snapshot.tf`.

### 7. **Installation de Terraform**
   - **Description** : Terraform doit être installé et configuré sur votre machine locale.
   - **Installation** :
     - Suivez les instructions d'installation pour Windows, macOS ou Linux disponibles sur le site officiel de Terraform.

---

### Résumé

Avant de lancer Terraform, assurez-vous que les éléments suivants sont créés et prêts à l'emploi :
1. **Paire de clés EC2**
2. **IDs de sous-réseaux**
3. **ID du VPC**
4. **Buckets S3** (si nécessaire)
5. **Permissions IAM** pour l'utilisateur ou le rôle IAM
6. **Adresse email pour SNS** (si nécessaire)
7. **Installation de Terraform** sur votre machine

Une fois ces éléments prêts, vous pouvez procéder au remplacement des variables dans les fichiers Terraform et déployer l'infrastructure.

