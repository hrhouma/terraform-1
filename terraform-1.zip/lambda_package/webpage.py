import boto3

def lambda_handler(event, context):
    source_bucket_name = "php-webpage-bucket-name"  # Replace with your source log bucket name
    destination_bucket_name = "php-log-bucket-name"  # Replace with your destination webpage bucket name

    s3_client = boto3.client('s3')

    # List all objects in the source bucket
    response = s3_client.list_objects_v2(Bucket=source_bucket_name)

    if 'Contents' in response:
        # Iterate over each object and copy it to the destination bucket
        for obj in response['Contents']:
            key = obj['Key']
            s3_client.copy_object(
                Bucket=destination_bucket_name,
                CopySource={'Bucket': source_bucket_name, 'Key': key},
                Key=key
            )

    return {
        'statusCode': 200,
        'body': 'Webpage sync completed successfully.'
    }
