import boto3
import datetime

def lambda_handler(event, context):
    # Replace the 'your_volume_id' with the actual EBS volume ID you want to snapshot
    volume_id = 'your_volume_id'

    # Create a unique snapshot description with the current date and time
    snapshot_description = f"Snapshot created on {datetime.datetime.now()}"

    # Create a snapshot of the EBS volume
    ec2 = boto3.client('ec2')
    snapshot_response = ec2.create_snapshot(VolumeId=volume_id, Description=snapshot_description)

    # Get the snapshot ID
    snapshot_id = snapshot_response['SnapshotId']

    # Print the snapshot ID for reference
    print(f"Snapshot created with ID: {snapshot_id}")
    
    # Optionally, you can add tags to the snapshot
    ec2.create_tags(Resources=[snapshot_id], Tags=[{'Key': 'Name', 'Value': 'MySnapshot'}])

    return {
        'statusCode': 200,
        'body': f'Snapshot created with ID: {snapshot_id}'
    }
